h46427
s 00000/00000/00000
d R 1.2 99/07/14 09:15:16 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/Fruit/Send.java
e
s 00026/00000/00000
d D 1.1 99/07/14 09:15:15 monicap 1 0
c date and time created 99/07/14 09:15:15 by monicap
e
u
U
f e 0
t
T
I 1
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Send extends Remote {

  public void sendCreditCard(String cardnum) throws RemoteException;
  public String getCreditCard() throws RemoteException;

  public void sendCustID(String cust) throws RemoteException;
  public String getCustID() throws RemoteException;

  public void sendAppleQnt(String apples) throws RemoteException;
  public String getAppleQnt() throws RemoteException;

  public void sendPeachQnt(String peaches) throws RemoteException;
  public String getPeachQnt() throws RemoteException;

  public void sendPearQnt(String pears) throws RemoteException;
  public String getPearQnt() throws RemoteException;

  public void sendTotalCost(double cost) throws RemoteException;
  public double getTotalCost() throws RemoteException;

  public void sendTotalItems(int items) throws RemoteException;
  public int getTotalItems() throws RemoteException;
}
E 1
