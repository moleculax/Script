import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

class RemoteServer extends UnicastRemoteObject
                 implements Send {

  private String cardnum;
  private String custID;
  private String apples;
  private String peaches;
  private String pears;
  private int items;
  private double cost;

  public RemoteServer() throws RemoteException {
    super();
  }


  public void sendCreditCard(String creditcard){
    cardnum = creditcard;
  }

  public String getCreditCard(){
    return cardnum;
  }

  public void sendCustID(String cust){
    custID = cust;
  }
  public String getCustID(){
    return custID;
  }

  public void sendAppleQnt(String apps){
    apples = apps;
  }
  public String getAppleQnt(){
    return apples;
  }

  public void sendPeachQnt(String pchs){
    peaches = pchs;
  }
  public String getPeachQnt(){
    return peaches;
  }

  public void sendPearQnt(String prs){
    pears = prs;
  }
  public String getPearQnt(){
    return pears;
  }

  public void sendTotalCost(double cst){
    cost = cst;
  }
  public double getTotalCost(){
    return cost;
  }

  public void sendTotalItems(int itm){
    items = itm;
  }
  public int getTotalItems(){
    return items;
  }


  public static void main(String[] args){
    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    String name = "//kq6py.eng.sun.com/Send";
    try {
      Send remoteServer = new RemoteServer();
      Naming.rebind(name, remoteServer);
      System.out.println("RemoteServer bound");
    } catch (java.rmi.RemoteException e) {
      System.out.println("Cannot create remote server object");
    } catch (java.net.MalformedURLException e) {
      System.out.println("Cannot look up server object");
    }
  }
}
