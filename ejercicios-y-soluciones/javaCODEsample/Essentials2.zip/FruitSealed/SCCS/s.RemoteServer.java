h65314
s 00000/00000/00000
d R 1.2 99/07/14 09:16:56 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitSealed/RemoteServer.java
e
s 00125/00000/00000
d D 1.1 99/07/14 09:16:55 monicap 1 0
c date and time created 99/07/14 09:16:55 by monicap
e
u
U
f e 0
t
T
I 1
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import java.security.*;
import javax.crypto.*;

class RemoteServer extends UnicastRemoteObject
                 implements Send, Serializable {

  private SealedObject cardnum;
  private byte[] encrypt;
  private String custID;
  private String apples;
  private String peaches;
  private String pears;
  private int items;
  private double cost;

  public RemoteServer() throws RemoteException {
    super();
  }

  public PublicKey getPublicKey(){
//Load from really safe place on disk
     PublicKey pubKey=null;
     try{
       String inputFileName = System.getProperty("user.home",
        File.separatorChar + "home" +
        File.separatorChar + "monicap") +
        File.separatorChar + "pubkey.txt";

       FileInputStream fstream = new FileInputStream(inputFileName);
       ObjectInputStream in = new ObjectInputStream(fstream);
       pubKey = (PublicKey)in.readObject();
       in.close();
     }catch(java.io.IOException e){
      System.out.println("File not found");
     }catch(java.lang.ClassNotFoundException e){
      System.out.println("PublicKey class not found");
     }
     return pubKey;
  }

  public void sendKey(SealedObject creditcard){
    cardnum = creditcard;
  }

  public SealedObject getKey(){
    return cardnum;
  }

  public byte[] getEncrypted(){
    return encrypt;
  }

  public void sendEncrypted(byte[] encrypted){
    encrypt = encrypted;
  }

  public void sendCustID(String cust){
    custID = cust;
  }
  public String getCustID(){
    return custID;
  }

  public void sendAppleQnt(String apps){
    apples = apps;
  }
  public String getAppleQnt(){
    return apples;
  }

  public void sendPeachQnt(String pchs){
    peaches = pchs;
  }
  public String getPeachQnt(){
    return peaches;
  }

  public void sendPearQnt(String prs){
    pears = prs;
  }
  public String getPearQnt(){
    return pears;
  }

  public void sendTotalCost(double cst){
    cost = cst;
  }
  public double getTotalCost(){
    return cost;
  }

  public void sendTotalItems(int itm){
    items = itm;
  }
  public int getTotalItems(){
    return items;
  }


  public static void main(String[] args){
    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    String name = "//kq6py.eng.sun.com/Send";
    try {
      Send remoteServer = new RemoteServer();
      Naming.rebind(name, remoteServer);
      System.out.println("RemoteServer bound");
    } catch (java.rmi.RemoteException e) {
      System.out.println("Cannot create remote server object");
    } catch (java.net.MalformedURLException e) {
      System.out.println("Cannot look up server object");
    }
  }
}
E 1
