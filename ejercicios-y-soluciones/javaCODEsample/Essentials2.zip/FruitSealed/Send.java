import java.rmi.Remote;
import java.rmi.RemoteException;
import javax.crypto.*;
import java.security.*;

public interface Send extends Remote {

  public PublicKey getPublicKey() throws RemoteException;

  public void sendEncrypted(byte[] encrypted) throws RemoteException;
  public byte[] getEncrypted() throws RemoteException;

  public void sendKey(SealedObject cardnum) throws RemoteException;
  public SealedObject getKey() throws RemoteException;

  public void sendCustID(String cust) throws RemoteException;
  public String getCustID() throws RemoteException;

  public void sendAppleQnt(String apples) throws RemoteException;
  public String getAppleQnt() throws RemoteException;

  public void sendPeachQnt(String peaches) throws RemoteException;
  public String getPeachQnt() throws RemoteException;

  public void sendPearQnt(String pears) throws RemoteException;
  public String getPearQnt() throws RemoteException;

  public void sendTotalCost(double cost) throws RemoteException;
  public double getTotalCost() throws RemoteException;

  public void sendTotalItems(int items) throws RemoteException;
  public int getTotalItems() throws RemoteException;
}
