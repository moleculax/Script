h52723
s 00001/00001/00182
d D 1.4 99/08/02 07:43:42 monicap 5 4
c 
e
s 00006/00019/00177
d D 1.3 99/07/29 13:28:08 monicap 4 3
c 
e
s 00002/00002/00194
d D 1.2 99/07/29 12:54:14 monicap 3 1
c 
e
s 00000/00000/00000
d R 1.2 99/07/14 09:15:34 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitCollect/RMIClient2.java
e
s 00196/00000/00000
d D 1.1 99/07/14 09:15:33 monicap 1 0
c date and time created 99/07/14 09:15:33 by monicap
e
u
U
f e 0
t
T
I 1
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;
D 4

E 4
import java.io.*;
import java.net.*;
D 4

E 4
import java.rmi.*;
import java.rmi.server.*;

D 4
import java.io.FileInputStream.*;
import java.io.RandomAccessFile.*;
import java.io.File;
E 4

import java.util.*;

class RMIClient2 extends JFrame
D 5
		 implements ActionListener {
E 5
I 5
		 implements ActionListener{
E 5

   JLabel creditCard, custID, apples, peaches, pears, total, cost, clicked;
   JButton view, reset;
   JPanel panel;
   JTextArea creditNo, customerNo, applesNo, peachesNo, pearsNo, itotal, icost; 
   static Send send;
   String customer;
D 4
   HashSet s = null;
E 4
I 4
   HashSet s = new HashSet();
E 4

   RMIClient2(){ //Begin Constructor
//Create labels
     creditCard = new JLabel("Credit Card:");
     custID = new JLabel("Customer ID:");
     apples = new JLabel("Apples:");
     peaches = new JLabel("Peaches:");
     pears = new JLabel("Pears:");
     total = new JLabel("Total Items:");
     cost = new JLabel("Total Cost:");

//Create text areas
     creditNo = new JTextArea();
     customerNo = new JTextArea();
     applesNo = new JTextArea();
     peachesNo = new JTextArea();
     pearsNo = new JTextArea();
     itotal = new JTextArea();
     icost = new JTextArea();

//Create buttons
     view = new JButton("View Order");
     view.addActionListener(this);

     reset = new JButton("Reset");
     reset.addActionListener(this);

//Create panel for 2-column layout
//Set white background color
     panel = new JPanel();
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     getContentPane().add(panel);
     panel.add(creditCard);
     panel.add(creditNo);

     panel.add(custID);
     panel.add(customerNo);

     panel.add(apples);
     panel.add(applesNo);

     panel.add(peaches);
     panel.add(peachesNo);

     panel.add(pears);
     panel.add(pearsNo);

     panel.add(total);
     panel.add(itotal);

     panel.add(cost);
     panel.add(icost);

     panel.add(view);
     panel.add(reset);

   } //End Constructor

//Create list of customer IDs
D 3
  public void customerList(String custID){
E 3
I 3
  public void addCustomer(String custID){
E 3
D 4
    if(s==null){
	s = new HashSet();
	s.add(custID);
    }else{
	s.add(custID);
    }
E 4
I 4
    s.add(custID);
    System.out.println("Customer ID added");
E 4
  }

//Print customer IDs
  public void print(){
D 4
    if(s!=null){
E 4
I 4
    if(s.size()!=0){
E 4
      Iterator it = s.iterator();
      while(it.hasNext()){
D 4
        try{
          String customer = (String)it.next();
          System.out.println(customer);
        }catch (java.util.NoSuchElementException e){
          System.out.println("No data available");
        }
E 4
I 4
          System.out.println(it.next());
E 4
      }
I 4
      System.out.println(s);
E 4
    }else{
      System.out.println("No customer IDs available");
    }
  }

  public void actionPerformed(ActionEvent event){
     Object source = event.getSource();
     String unit, i;
     double cost;
     Double price;
     int items;
     Integer itms;
     DataOrder order = new DataOrder();

//If View button pressed
//Get data from server and display it
     if(source == view){
        try{
          order  = send.getOrder();
	  creditNo.setText(order.cardnum);
	  customerNo.setText(order.custID);
//Get customer ID and add to list
D 3
          customerList(order.custID);
E 3
I 3
          addCustomer(order.custID);
E 3
          applesNo.setText(order.apples);
          peachesNo.setText(order.peaches);
          pearsNo.setText(order.pears);

	  cost = order.icost;
	  price = new Double(cost);
	  unit = price.toString();
	  icost.setText(unit);

	  items = order.itotal;
	  itms = new Integer(items);
	  i = itms.toString();
	  itotal.setText(i);
	} catch (java.rmi.RemoteException e) {
	  System.out.println("Cannot access data in server");	
	}
//Print
	print();
     }

//If Reset button pressed
//Clear all fields
     if(source == reset){
	creditNo.setText("");
	customerNo.setText("");
	applesNo.setText("");
	peachesNo.setText("");	
	pearsNo.setText("");
	itotal.setText("");
	icost.setText("");
     }
  }
  
   public static void main(String[] args){
        RMIClient2 frame = new RMIClient2();
	frame.setTitle("Fruit Order");
        WindowListener l = new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                        System.exit(0);
                }
        };

        frame.addWindowListener(l);
        frame.pack();
        frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.NotBoundException e) {
      System.out.println("Cannot access data in server");
    } catch(java.rmi.RemoteException e){
      System.out.println("Cannot access data in server");
    } catch(java.net.MalformedURLException e) {
      System.out.println("Cannot access data in server");
    }
  }
}
E 1
