h46082
s 00000/00000/00000
d R 1.2 99/07/14 09:15:35 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitCollect/Send.java
e
s 00007/00000/00000
d D 1.1 99/07/14 09:15:34 monicap 1 0
c date and time created 99/07/14 09:15:34 by monicap
e
u
U
f e 0
t
T
I 1
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Send extends Remote {
  public void sendOrder(DataOrder order) throws RemoteException;
  public DataOrder getOrder() throws RemoteException;
}
E 1
