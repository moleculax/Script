import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
//import javax.swing.*;
import com.sun.java.swing.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import java.io.FileInputStream.*;
import java.io.RandomAccessFile.*;
import java.io.File;

import java.util.*;

import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;

class RMIClient2 extends JFrame
		 implements ActionListener {

   JLabel creditCard, custID, apples, peaches, pears, total, cost, clicked;
   JButton view, reset;
   JPanel panel;
   JTextArea creditNo, customerNo, applesNo, peachesNo, pearsNo, itotal, icost; 
   Socket socket = null;
   PrintWriter out = null;
   static Send send;
   String customer;

   RMIClient2(){ //Begin Constructor
//Create labels
     creditCard = new JLabel("Credit Card:");
     custID = new JLabel("Customer ID:");
     apples = new JLabel("Apples:");
     peaches = new JLabel("Peaches:");
     pears = new JLabel("Pears:");
     total = new JLabel("Total Items:");
     cost = new JLabel("Total Cost:");

//Create text area components
     creditNo = new JTextArea();
     customerNo = new JTextArea();
     applesNo = new JTextArea();
     peachesNo = new JTextArea();
     pearsNo = new JTextArea();
     itotal = new JTextArea();
     icost = new JTextArea();

//Create buttons
     view = new JButton("View Order");
     view.addActionListener(this);

     reset = new JButton("Reset");
     reset.addActionListener(this);

//Create panel for 2-column layout
//Set white background color
     panel = new JPanel();
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     getContentPane().add(panel);
     panel.add(creditCard);
     panel.add(creditNo);

     panel.add(custID);
     panel.add(customerNo);

     panel.add(apples);
     panel.add(applesNo);

     panel.add(peaches);
     panel.add(peachesNo);

     panel.add(pears);
     panel.add(pearsNo);

     panel.add(total);
     panel.add(itotal);

     panel.add(cost);
     panel.add(icost);

     panel.add(view);
     panel.add(reset);

   } //End Constructor

/*
  public String decrypt(sealed key,
                        encrypted credit card number){
  //  Get private key from file
  //  Create asymmetric cipher (do not use RSA)
  //  Initialize cipher for decryption with private key
  //  Unseal wrapped session key using asymmetric cipher
  //  Create symmetric cipher
  //  Initialize cipher for decryption with session key
  //  Decrypt credit card number with symmetric cipher
  }
*/

  public void actionPerformed(ActionEvent event){
     Object source = event.getSource();
     String text=null, unit, i;
     byte[] wrappedKey;
     byte[] encrypted;
     double cost;
     Double price;
     int items;
     Integer itms;

//If View button pressed
//Get data from server and display it
     if(source == view){
        try{
          wrappedKey = send.getKey();
	  encrypted = send.getEncrypted();
//Decrypt credit card number
          String credit = decrypt(sealed, encrypted);
	  creditNo.setText(new String(credit));

	  text = send.getCustID(); 
	  customerNo.setText(text);

          text = send.getAppleQnt();
          applesNo.setText(text);

          text = send.getPeachQnt();
          peachesNo.setText(text);

          text = send.getPearQnt();
          pearsNo.setText(text);

	  cost = send.getTotalCost();
	  price = new Double(cost);
	  unit = price.toString();
	  icost.setText(unit);

	  items = send.getTotalItems();
	  itms = new Integer(items);
	  i = itms.toString();
	  itotal.setText(i);

	} catch (java.rmi.RemoteException e) {
	  System.out.println("sendData exception: " + e.getMessage());	
	}
     }

//If Reset button pressed
//Clear all fields
     if(source == reset){
	creditNo.setText("");
	customerNo.setText("");
	applesNo.setText("");
	peachesNo.setText("");	
	pearsNo.setText("");
	itotal.setText("");
	icost.setText("");
     }
  }
  
   public static void main(String[] args){
        RMIClient2 frame = new RMIClient2();
	frame.setTitle("Fruit Order");
        WindowListener l = new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                        System.exit(0);
                }
        };

        frame.addWindowListener(l);
        frame.pack();
        frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.NotBoundException e) {
      System.out.println("Cannot access data in server");
    } catch(java.rmi.RemoteException e){
      System.out.println("Cannot access data in server");
    } catch(java.net.MalformedURLException e) {
      System.out.println("Cannot access data in server");
    }
  }
}
