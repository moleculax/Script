h39865
s 00008/00008/00191
d D 1.3 99/07/22 14:55:24 monicap 4 3
c 
e
s 00008/00008/00191
d D 1.2 99/07/14 13:54:55 monicap 3 1
c 
e
s 00000/00000/00000
d R 1.2 99/07/14 09:16:37 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitPseudo/RMIClient2.java
e
s 00199/00000/00000
d D 1.1 99/07/14 09:16:36 monicap 1 0
c date and time created 99/07/14 09:16:36 by monicap
e
u
U
f e 0
t
T
I 1
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
//import javax.swing.*;
import com.sun.java.swing.*;


import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import java.io.FileInputStream.*;
import java.io.RandomAccessFile.*;
import java.io.File;

import java.util.*;

import javax.crypto.*;
import java.security.*;

class RMIClient2 extends JFrame
		 implements ActionListener {

   JLabel creditCard, custID, apples, peaches, pears, total, cost, clicked;
   JButton view, reset;
   JPanel panel;
   JTextArea creditNo, customerNo, applesNo, peachesNo, pearsNo, itotal, icost; 
   Socket socket = null;
   PrintWriter out = null;
   static Send send;
   String customer;

   RMIClient2(){ //Begin Constructor
     creditCard = new JLabel("Credit Card:");
     custID = new JLabel("Customer ID:");
     apples = new JLabel("Apples:");
     peaches = new JLabel("Peaches:");
     pears = new JLabel("Pears:");
     total = new JLabel("Total Items:");
     cost = new JLabel("Total Cost:");

     creditNo = new JTextArea();
     customerNo = new JTextArea();
     applesNo = new JTextArea();
     peachesNo = new JTextArea();
     pearsNo = new JTextArea();
     itotal = new JTextArea();
     icost = new JTextArea();

     view = new JButton("View Order");
     view.addActionListener(this);

     reset = new JButton("Reset");
     reset.addActionListener(this);

     panel = new JPanel();
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);
     getContentPane().add(panel);

     panel.add(creditCard);
     panel.add(creditNo);

     panel.add(custID);
     panel.add(customerNo);

     panel.add(apples);
     panel.add(applesNo);

     panel.add(peaches);
     panel.add(peachesNo);

     panel.add(pears);
     panel.add(pearsNo);

     panel.add(total);
     panel.add(itotal);

     panel.add(cost);
     panel.add(icost);

     panel.add(view);
     panel.add(reset);

   } //End Constructor

  public void writeToFile(String custID) throws java.io.IOException{
    byte b[] = custID.getBytes();
    File outputFile = new File(File.separatorChar + 
	"home" + File.separatorChar + 
	"monicap" + File.separatorChar + 
	"text.txt");
    RandomAccessFile out = new RandomAccessFile(outputFile, "rw");
    out.seek(outputFile.length());       
    out.write(b);
    out.writeByte(10);
    out.close();
  }

D 4
  public String decrypt(symmetric key, 
			encrypted credit card number){

D 3
    Deserialize sealed and locked session key
    Get private key from file
    Create asymmetric cipher
    Initialize cipher for decryption with private key
    Unseal wrapped session key using asymmetric cipher
    Create symmetric cipher
    Initialize cipher for decryption with session key
    Decrypt credit card number with symmetric cipher
E 3
I 3
    //Deserialize sealed and locked session key
E 4
I 4
  public String decrypt(symmetric key,
                        encrypted credit card number){
    //Decrypt credit card number
E 4
    //Get private key from file
D 4
    //Create asymmetric cipher
E 4
I 4
    //Create asymmetric cipher (RSA)
E 4
    //Initialize cipher for decryption with private key
D 4
    //Unseal wrapped session key using asymmetric cipher
E 4
I 4
    //Decrypt symmetric key
    //Instantiate symmetric key
E 4
    //Create symmetric cipher
D 4
    //Initialize cipher for decryption with session key
    //Decrypt credit card number with symmetric cipher
E 4
I 4
    //Initialize Cipher for decryption with session key
    //Decrypt credit card number with symmetric Cipher
E 4
E 3
  }

  public void actionPerformed(ActionEvent event){
     Object source = event.getSource();
     String text=null, unit, i;
     SealedObject sealed;
     byte[] encrypted;
     double cost;
     Double price;
     int items;
     Integer itms;

     if(source == view){
        try{
          sealed = send.getCreditCard();
	  encrypted = send.getEncrypted();
          String credit = decrypt(sealed, encrypted);
	  creditNo.setText(credit);

	  text = send.getCustID(); 
	  customerNo.setText(text);
	  writeToFile(text);

          text = send.getAppleQnt();
          applesNo.setText(text);

          text = send.getPeachQnt();
          peachesNo.setText(text);

          text = send.getPearQnt();
          pearsNo.setText(text);

	  cost = send.getTotalCost();
	  price = new Double(cost);
	  unit = price.toString();
	  icost.setText(unit);

	  items = send.getTotalItems();
	  itms = new Integer(items);
	  i = itms.toString();
	  itotal.setText(i);

	} catch (java.rmi.RemoteException e) {
	  System.out.println("Cannot access data in server");	
	}
     }

     if(source == reset){
	creditNo.setText("");
	customerNo.setText("");
	applesNo.setText("");
	peachesNo.setText("");	
	pearsNo.setText("");
	itotal.setText("");
	icost.setText("");
     }
  }
  
   public static void main(String[] args){
        RMIClient2 frame = new RMIClient2();
	frame.setTitle("Fruit Order");
        WindowListener l = new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                        System.exit(0);
                }
        };

        frame.addWindowListener(l);
        frame.pack();
        frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.RemoteException e) {
      System.out.println("Cannot create remote server object");
    } catch (java.net.MalformedURLException e) {
      System.out.println("Cannot look up server object");
    } catch(java.rmi.NotBoundException e) {
      System.out.println("Cannot access data in server");
    }
  }
}
E 1
