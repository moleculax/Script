h38805
s 00000/00000/00000
d R 1.2 99/07/14 09:17:13 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitSerial/DataOrder.java
e
s 00009/00000/00000
d D 1.1 99/07/14 09:17:12 monicap 1 0
c date and time created 99/07/14 09:17:12 by monicap
e
u
U
f e 0
t
T
I 1
import java.io.*;

class DataOrder implements Serializable{

  String apples, peaches, pears, cardnum, custID;
  double icost;
  int itotal;
}

E 1
