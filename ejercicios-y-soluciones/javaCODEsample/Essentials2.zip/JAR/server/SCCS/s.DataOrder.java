h42791
s 00000/00000/00000
d R 1.2 99/07/14 13:45:59 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/JAR/server/DataOrder.java
e
s 00011/00000/00000
d D 1.1 99/07/14 13:45:58 monicap 1 0
c date and time created 99/07/14 13:45:58 by monicap
e
u
U
f e 0
t
T
I 1
package server;

import java.io.*;

public class DataOrder implements Serializable{

  public String apples, peaches, pears, cardnum, custID;
  public double icost;
  public int itotal;
}

E 1
