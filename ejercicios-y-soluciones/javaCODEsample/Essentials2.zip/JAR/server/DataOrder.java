package server;

import java.io.*;

public class DataOrder implements Serializable{

  public String apples, peaches, pears, cardnum, custID;
  public double icost;
  public int itotal;
}

