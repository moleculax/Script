package client1;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.WindowListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
import java.io.File;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.util.ResourceBundle;
import java.util.Locale;
import java.text.NumberFormat;
import server.Send;

class RMIClientView extends JFrame { 
  protected JLabel col1, col2; 
  protected JLabel totalItems, totalCost; 
  protected JLabel cardNum, custID;
  protected JLabel applechk, pearchk, peachchk;
  protected JButton purchase, reset;
  protected JPanel panel;
  protected JTextField appleqnt, pearqnt, peachqnt; 
  protected JTextField creditCard, customer;
  protected JTextArea items, cost;
  protected static Send send;

//Internationalization variables
  private static Locale currentLocale;
  private static ResourceBundle messages;
  private static String language, country;
  private NumberFormat numFormat;

  private RMIClientView(){ //Begin Constructor
    setTitle(messages.getString("title"));

//Create left and right column labels
    col1 = new JLabel(messages.getString("1col"));
    col2 = new JLabel(messages.getString("2col"));

//Create labels and text field components
   applechk = new JLabel("   " + messages.getString("apples"));
    appleqnt = new JTextField();
    pearchk = new JLabel("   " + messages.getString("pears"));
    pearqnt = new JTextField();
    peachchk = new JLabel("   " + messages.getString("peaches"));
    peachqnt = new JTextField();
    cardNum = new JLabel("   " + messages.getString("card"));
    creditCard = new JTextField();
    pearqnt.setNextFocusableComponent(creditCard);
    customer = new JTextField();
    custID = new JLabel("   " + messages.getString("customer"));

//Create labels and text area components
    totalItems = new JLabel("   " + messages.getString("items"));
    totalCost = new JLabel("   " + messages.getString("cost"));
    items = new JTextArea();
    cost = new JTextArea();

//Create buttons and make action listeners
    purchase = new JButton(messages.getString("purchase"));
    reset = new JButton(messages.getString("reset"));

//Create a panel for the components
    panel = new JPanel();

//Set panel layout to 2-column grid
//on a white background
    panel.setLayout(new GridLayout(0,2));
    panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
    getContentPane().add(panel);
    panel.add(col1);
    panel.add(col2);
    panel.add(applechk);
    panel.add(appleqnt);
    panel.add(peachchk);
    panel.add(peachqnt);
    panel.add(pearchk);
    panel.add(pearqnt);
    panel.add(totalItems);
    panel.add(items);
    panel.add(totalCost);
    panel.add(cost);
    panel.add(cardNum);
    panel.add(creditCard);
    panel.add(custID);
    panel.add(customer);
    panel.add(reset);
    panel.add(purchase);
  } //End Constructor

  public static void main(String[] args) {
    if (args.length != 3) {
      language = new String("en");
      country = new String ("US");
      System.out.println("English");
    } else {
      language = new String(args[1]);
      country = new String(args[2]);
      System.out.println(language + country);
    }
    currentLocale = new Locale(language, country);
    messages = ResourceBundle.getBundle("client1" + 
		File.separatorChar + "MessagesBundle", 
		currentLocale);
    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    };
  
    RMIClientView frame = new RMIClientView();
    frame.addWindowListener(l);
    frame.pack();
    frame.setVisible(true);
    RMIClientController control = new RMIClientController(frame, messages, currentLocale);
    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.NotBoundException e) {
      System.out.println(messages.getString("nolookup"));
    } catch (java.rmi.RemoteException e) {
      System.out.println(messages.getString("nolookup"));
    } catch (java.net.MalformedURLException e) {
      System.out.println(messages.getString("nollokup"));
    }
  }
}
