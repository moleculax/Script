h01057
s 00000/00000/00000
d R 1.2 00/11/14 12:37:58 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/OO/client1/RMIClientController.java
e
s 00119/00000/00000
d D 1.1 00/11/14 12:37:57 monicap 1 0
c date and time created 00/11/14 12:37:57 by monicap
e
u
U
f e 0
t
T
I 1
package client1;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ResourceBundle;
import java.util.Locale;
import java.text.NumberFormat;
import server.DataOrder;

class RMIClientController implements ActionListener { 
  private RMIClientView frame;
  private ResourceBundle messages;
  private NumberFormat numFormat;
  private Locale currentLocale; 

  protected RMIClientController(RMIClientView frame, 
				ResourceBundle messages, 
				Locale currentLocale){ 
    this.frame = frame;
    this.messages = messages;
    this.currentLocale = currentLocale;
//Make action listeners
    frame.purchase.addActionListener(this);
    frame.reset.addActionListener(this);
    frame.appleqnt.addActionListener(this);
    frame.peachqnt.addActionListener(this);
    frame.pearqnt.addActionListener(this);
  } //End Constructor

  public void actionPerformed(ActionEvent event) {
   Object source = event.getSource();
   Integer applesNo, peachesNo, pearsNo, num;
   Double cost;
   String text, text2;
   DataOrder order = new DataOrder();
//If Purchase button pressed  . . .
   if (source == frame.purchase) {
//Get data from text fields
    order.cardnum = frame.creditCard.getText();
    order.custID = frame.customer.getText();
    order.apples = frame.appleqnt.getText();
    order.peaches = frame.peachqnt.getText();
    order.pears = frame.pearqnt.getText();

//Calculate total items
    if (order.apples.length() > 0) {
//Catch invalid number error
      try {
        applesNo = Integer.valueOf(order.apples);
        order.itotal += applesNo.intValue();
      } catch (java.lang.NumberFormatException e) {
        frame.appleqnt.setText(messages.getString("invalid"));
      }
    } else {
      /* else no need to change the total */
    }
    if(order.peaches.length() > 0){

//Catch invalid number error
      try {
        peachesNo = Integer.valueOf(order.peaches);
        order.itotal += peachesNo.intValue();
      } catch(java.lang.NumberFormatException e) {
        frame.peachqnt.setText(messages.getString("invalid"));
      }
    } else {
      /* else no need to change the total */
    }
    if(order.pears.length() > 0){

//Catch invalid number error
      try {
        pearsNo = Integer.valueOf(order.pears);
        order.itotal += pearsNo.intValue();
      } catch (java.lang.NumberFormatException e) {
        frame.pearqnt.setText(messages.getString("invalid"));
      }
    } else {
      /* else no need to change the total */
    }

//Create number formatter
     numFormat = NumberFormat.getNumberInstance(currentLocale);
//Display running total
     text = numFormat.format(order.itotal);
     frame.items.setText(text);
//Calculate and display running cost
     order.icost = (order.itotal * 1.25);
     text2 = numFormat.format(order.icost);
     frame.cost.setText(text2);
     try {
        frame.send.sendOrder(order);
      } catch (java.rmi.RemoteException e) {
        System.out.println(messages.getString("send"));
      } catch (java.io.IOException e) {
        System.out.println("Unable to write to file");

      }
   }
//If Reset button pressed 
//Clear all fields
    if (source == frame.reset) {
     frame.creditCard.setText("");
     frame.appleqnt.setText("");
     frame.peachqnt.setText("");
     frame.pearqnt.setText("");
     frame.creditCard.setText("");
     frame.customer.setText("");
     order.icost = 0;
     cost = new Double(order.icost);
     text2 = cost.toString();
     frame.cost.setText(text2);
     order.itotal = 0;
     num = new Integer(order.itotal);
     text = num.toString();
     frame.items.setText(text);
    }
  }
}
E 1
