h46968
s 00005/00017/00203
d D 1.3 99/07/29 13:31:55 monicap 4 3
c 
e
s 00002/00002/00218
d D 1.2 99/07/29 12:55:30 monicap 3 1
c 
e
s 00000/00000/00000
d R 1.2 99/07/14 09:16:19 Codemgr 2 1
c SunPro Code Manager data about conflicts, renames, etc...
c Name history : 1 0 developer/onlineTraining/Programming/BasicJava2/Code/FruitInt/RMIClient2.java
e
s 00220/00000/00000
d D 1.1 99/07/14 09:16:18 monicap 1 0
c date and time created 99/07/14 09:16:18 by monicap
e
u
U
f e 0
t
T
I 1
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

D 4
import java.io.FileInputStream.*;
import java.io.RandomAccessFile.*;
import java.io.File;

E 4
import java.util.*;
import java.text.*;

class RMIClient2 extends JFrame
		 implements ActionListener {

   JLabel creditCard, custID, apples, peaches, pears, total, cost, clicked;
   JButton view, reset;
   JPanel panel;
   JTextArea creditNo, customerNo, applesNo, peachesNo, pearsNo, itotal, icost; 
   static Send send;
   String customer;
   Set s = null;

//Internationalization variables
   static Locale currentLocale;
   static ResourceBundle messages;
   static String language, country;
   NumberFormat numFormat;

   RMIClient2(){ //Begin Constructor

     setTitle(messages.getString("title"));

//Create labels
     creditCard = new JLabel(messages.getString("card"));
     custID = new JLabel(messages.getString("customer"));
     apples = new JLabel(messages.getString("apples"));
     peaches = new JLabel(messages.getString("peaches"));
     pears = new JLabel(messages.getString("pears"));
     total = new JLabel(messages.getString("items"));
     cost = new JLabel(messages.getString("cost"));

//Create text areas
     creditNo = new JTextArea();
     customerNo = new JTextArea();
     applesNo = new JTextArea();
     peachesNo = new JTextArea();
     pearsNo = new JTextArea();
     itotal = new JTextArea();
     icost = new JTextArea();

//Create buttons
     view = new JButton(messages.getString("view"));
     view.addActionListener(this);

     reset = new JButton(messages.getString("reset"));
     reset.addActionListener(this);

//Create panel for 2-column layout
//Set white background color
     panel = new JPanel();
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     getContentPane().add(panel);
     panel.add(creditCard);
     panel.add(creditNo);

     panel.add(custID);
     panel.add(customerNo);

     panel.add(apples);
     panel.add(applesNo);

     panel.add(peaches);
     panel.add(peachesNo);

     panel.add(pears);
     panel.add(pearsNo);

     panel.add(total);
     panel.add(itotal);

     panel.add(cost);
     panel.add(icost);

     panel.add(view);
     panel.add(reset);

   } //End Constructor

//Create list of customer IDs
D 3
  public void customerList(String custID){
E 3
I 3
  public void addCustomer(String custID){
E 3
D 4
    if(s==null){
	s = new HashSet();
	s.add(custID);
    }else{
	s.add(custID);
    }
E 4
I 4
    s.add(custID);
    System.out.println("Customer ID added");
E 4
  }

//Print customer IDs
  public void print(){
D 4
    if(s!=null){
E 4
I 4
    if(s.size()!=0){
E 4
      Iterator it = s.iterator();
      while(it.hasNext()){
D 4
        try{
          String customer = (String)it.next();
          System.out.println(customer);
        }catch (java.util.NoSuchElementException e){
          System.out.println("No data available");
        }
E 4
I 4
          System.out.println(it.next());
E 4
      }
I 4
      System.out.println(s);
E 4
    }else{
      System.out.println("No customer IDs available");
    }
  }

  public void actionPerformed(ActionEvent event){
     Object source = event.getSource();
     String unit, i;
     double cost;
     Double price;
     int items;
     Integer itms;
     DataOrder order = new DataOrder();

//If View button pressed
//Get data from server and display it
     if(source == view){
        try{
          order  = send.getOrder();
	  creditNo.setText(order.cardnum);
	  customerNo.setText(order.custID);
//Get customer ID and add to list
D 3
          customerList(order.custID);
E 3
I 3
          addCustomer(order.custID);
E 3
          applesNo.setText(order.apples);
          peachesNo.setText(order.peaches);
          pearsNo.setText(order.pears);

//Create number formatter
          numFormat = NumberFormat.getNumberInstance(currentLocale);

	  price = new Double(order.icost);
	  unit = numFormat.format(price);
	  icost.setText(unit);

	  itms = new Integer(order.itotal);
	  i = numFormat.format(order.itotal);
	  itotal.setText(i);
	} catch (java.rmi.RemoteException e) {
	  System.out.println("Cannot access data in server");	
	}
//Print
	print();
     }

//If Reset button pressed
//Clear all fields
     if(source == reset){
	creditNo.setText("");
	customerNo.setText("");
	applesNo.setText("");
	peachesNo.setText("");	
	pearsNo.setText("");
	itotal.setText("");
	icost.setText("");
     }
  }
  
  public static void main(String[] args){
    if(args.length != 3) {
      language = new String("en");
      country = new String ("US");
      System.out.println("English");
    }else{
      language = new String(args[1]);
      country = new String(args[2]);
      System.out.println(language + country);
    }

    currentLocale = new Locale(language, country);
    messages = ResourceBundle.getBundle("MessagesBundle", currentLocale);

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    };

    RMIClient2 frame = new RMIClient2();
    frame.addWindowListener(l);
    frame.pack();
    frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.NotBoundException e) {
      System.out.println(messages.getString("nolookup"));
    } catch(java.rmi.RemoteException e){
      System.out.println(messages.getString("nolookup"));
    } catch(java.net.MalformedURLException e) {
      System.out.println(messages.getString("nolookup"));
    }

  }
}
E 1
