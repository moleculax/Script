public class Color {
    private String name;

    private Color(String name) {
        this.name = name;
    }

    public static Color RED =   new Color("red");
    public static Color GREEN = new Color("red");
    public static Color BLUE =  new Color("red");
}
