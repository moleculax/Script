public class Test implements PhysicalConstants {
    public static void main(String[] args) {
        System.out.println("Avogadro's number: " + AVOGADROS_NUMBER);
    }
}
