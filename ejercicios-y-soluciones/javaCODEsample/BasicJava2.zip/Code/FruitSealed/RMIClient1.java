import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
//import javax.swing.*;
import com.sun.java.swing.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import javax.crypto.*;
import java.security.*;
import java.security.interfaces.*;

class RMIClient1 extends JFrame
		 implements ActionListener{ 

   JLabel col1, col2; 
   JLabel totalItems, totalCost; 
   JLabel cardNum, custID;
   JLabel applechk, pearchk, peachchk;

   JButton purchase, reset;
   JPanel panel;

   JTextField appleqnt, pearqnt, peachqnt; 
   JTextField creditCard, customer;
   JTextArea items, cost;

   static Send send;
   int itotal=0; 
   double icost=0;

   RMIClient1(){ //Begin Constructor
//Create left and right column labels
     col1 = new JLabel("Select Items");
     col2 = new JLabel("Specify Quantity");

//Create labels and text field components
     applechk = new JLabel("   Apples");
     appleqnt = new JTextField();
     appleqnt.addActionListener(this);

     pearchk = new JLabel("   Pears");
     pearqnt = new JTextField();
     pearqnt.addActionListener(this);

     peachchk = new JLabel("   Peaches");
     peachqnt = new JTextField();
     peachqnt.addActionListener(this);

     cardNum = new JLabel("   Credit Card:");
     creditCard = new JTextField();
     pearqnt.setNextFocusableComponent(creditCard);

     customer = new JTextField();
     custID = new JLabel("   Customer ID:");

//Create labels and text area components
     totalItems = new JLabel("Total Items:");
     totalCost = new JLabel("Total Cost:");
     items = new JTextArea();
     cost = new JTextArea();

//Create buttons and make action listeners
     purchase = new JButton("Purchase");
     purchase.addActionListener(this);

     reset = new JButton("Reset");
     reset.addActionListener(this);
     creditCard.setNextFocusableComponent(reset);

//Create a panel for the components
     panel = new JPanel();

//Set panel layout to 2-column grid
//on a white background
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     getContentPane().add(panel);
     panel.add(col1);
     panel.add(col2);

     panel.add(applechk);
     panel.add(appleqnt);

     panel.add(peachchk);
     panel.add(peachqnt);

     panel.add(pearchk);
     panel.add(pearqnt);

     panel.add(totalItems);
     panel.add(items);

     panel.add(totalCost);
     panel.add(cost);

     panel.add(cardNum);
     panel.add(creditCard);

     panel.add(custID);
     panel.add(customer);

     panel.add(reset);
     panel.add(purchase);

   } //End Constructor

  private void encrypt(String cardnum){
    Cipher c=null, c2=null;
    KeyGenerator keyGen;
    SecretKey secretKey=null;
    RSAPublicKey pubKey=null;
    SealedObject sealed=null;
    byte[] encrypted=null;
    String s="text";

//Create Cipher for symmetric key encryption (DES)
//Create a key generator 
//Create a secret (session) key with key generator
    try{
      c = Cipher.getInstance("DES/ECB/PKCS5Padding");
      keyGen = KeyGenerator.getInstance("DES");
      keyGen.init(new SecureRandom());
      secretKey=keyGen.generateKey();
     } catch (java.security.NoSuchAlgorithmException e) {
       System.out.println("No such algorithm");
     } catch(javax.crypto.NoSuchPaddingException e){
       System.out.println("No such padding");
     }

//Initialize Cipher for encryption with session key
//Encrypt credit card number with Cipher
    try{
      c.init(Cipher.ENCRYPT_MODE, secretKey);
      encrypted=c.doFinal(s.getBytes());
      System.out.println("Cipher Text:");
      System.out.println(new String(encrypted));
      System.out.println();
    } catch (java.security.InvalidKeyException e) {
      System.out.println("Invalid Key");
    } catch(javax.crypto.IllegalBlockSizeException e){
      System.out.println("Illegal block size");
    } catch (javax.crypto.BadPaddingException e) {
      System.out.println("Bad Padding");
    }

//Get public key from server
    try{
      pubKey = (RSAPublicKey)send.getPublicKey();
    }catch (java.rmi.RemoteException e){
      System.out.println("Key not availalbe");
    }

//Create Cipher for asymmetric encryption (RSA)
//Initialize Cipher for encryption with session key
    try{
      c2 = Cipher.getInstance("RSA");
      c2.init(Cipher.ENCRYPT_MODE, pubKey);
     } catch (java.security.NoSuchAlgorithmException e) {
        System.out.println("No such algorithm");
     } catch (javax.crypto.NoSuchPaddingException e) {
        System.out.println("No such padding");
     } catch (java.security.InvalidKeyException e) {
	System.out.println("Invalid key");
     }  

//Seal session key in SealedObject using asymmetric Cipher 
    try{ 
      sealed = new SealedObject(secretKey, c2);
    }catch (javax.crypto.IllegalBlockSizeException  e){
	System.out.println("Illegal block size");
    }catch (java.io.IOException e){
        System.out.println("Unable to seal session key");
    }
    
//Send encrypted message and 
//sealed session key to server
   try{
        send.sendKey(sealed);
        send.sendEncrypted(encrypted);
   }catch(java.rmi.RemoteException e){
        System.out.println("Unable to send key"); 
  }
}

  public void actionPerformed(ActionEvent event){
   Object source = event.getSource();
   Integer applesNo, peachesNo, pearsNo, num;
   Double cost;
   String number, cardnum, custID, apples, peaches, pears, text, text2;

//If Purchase button pressed
   if(source == purchase){
//Get data from text fields
    cardnum = creditCard.getText();
    custID = customer.getText();
    apples = appleqnt.getText();
    peaches = peachqnt.getText();
    pears = pearqnt.getText();

//Calculate total items
    if(apples.length() > 0){
//Catch invalid number error
      try{
        applesNo = Integer.valueOf(apples);
        itotal += applesNo.intValue();
      }catch(java.lang.NumberFormatException e){
        appleqnt.setText("Invalid Value");
      }
    } else {
      itotal += 0;
    }

    if(peaches.length() > 0){
//Catch invalid number error
      try{
        peachesNo = Integer.valueOf(peaches);
        itotal += peachesNo.intValue();
      }catch(java.lang.NumberFormatException e){
        peachqnt.setText("Invalid Value");
      }
    } else {
      itotal += 0;
    }

    if(pears.length() > 0){
//Catch invalid number error
      try{
        pearsNo = Integer.valueOf(pears);
        itotal += pearsNo.intValue();
      }catch(java.lang.NumberFormatException e){
        pearqnt.setText("Invalid Value");
      }
    } else {
      itotal += 0;
    }

//Display running total
     num = new Integer(itotal);
     text = num.toString();
     this.items.setText(text);

//Calculate and display running cost
     icost = (itotal * 1.25);
     cost = new Double(icost);
     text2 = cost.toString();
     this.cost.setText(text2);

//Encrypt credit card number
     encrypt(cardnum);

//Send data over net
     try{
        send.sendCustID(custID);
        send.sendAppleQnt(apples);
        send.sendPeachQnt(peaches);
        send.sendPearQnt(pears);
	send.sendTotalCost(icost);
        send.sendTotalItems(itotal);
      } catch (java.rmi.RemoteException e) {
	System.out.println("sendData exception: " + e.getMessage());	
      }
   }

//If Reset button pressed 
//Clear all fields
    if(source == reset){
     creditCard.setText("");
     appleqnt.setText("");
     peachqnt.setText("");
     pearqnt.setText("");
     creditCard.setText("");
     customer.setText("");

     icost = 0;
     cost = new Double(icost);
     text2 = cost.toString();
     this.cost.setText(text2);

     itotal = 0;
     num = new Integer(itotal);
     text = num.toString();
     this.items.setText(text);
    }
  }

  public static void main(String[] args){
    try{
      UIManager.setLookAndFeel(
        UIManager.getCrossPlatformLookAndFeelClassName());
    }catch (Exception e) {
      System.out.println("Couldn't use the cross-platform"
        + "look and feel: " + e);
    }

    RMIClient1 frame = new RMIClient1();
    frame.setTitle("Fruit $1.25 Each");
    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    };

    frame.addWindowListener(l);
    frame.pack();
    frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (Exception e) {
      System.out.println("RMIClient1 exception: " + e.getMessage());
      e.printStackTrace();
    }
  }
}
