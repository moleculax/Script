import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import java.io.FileInputStream.*;
import java.io.RandomAccessFile.*;
import java.io.File;

import java.util.*;

class RMIClient2 extends JFrame
		 implements ActionListener {

   JLabel creditCard, custID, apples, peaches, pears, total, cost, clicked;
   JButton view, reset;
   JPanel panel;
   JTextArea creditNo, customerNo, applesNo, peachesNo, pearsNo, itotal, icost; 
   static Send send;
   String customer;
   Set s = null;

   RMIClient2(){ //Begin Constructor
//Create labels
     creditCard = new JLabel("Credit Card:");
     custID = new JLabel("Customer ID:");
     apples = new JLabel("Apples:");
     peaches = new JLabel("Peaches:");
     pears = new JLabel("Pears:");
     total = new JLabel("Total Items:");
     cost = new JLabel("Total Cost:");

//Create text areas
     creditNo = new JTextArea();
     customerNo = new JTextArea();
     applesNo = new JTextArea();
     peachesNo = new JTextArea();
     pearsNo = new JTextArea();
     itotal = new JTextArea();
     icost = new JTextArea();

//Create buttons
     view = new JButton("View Order");
     view.addActionListener(this);

     reset = new JButton("Reset");
     reset.addActionListener(this);

//Create panel for 2-column layout
//Set white background color
     panel = new JPanel();
     panel.setLayout(new GridLayout(0,2));
     panel.setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     getContentPane().add(panel);
     panel.add(creditCard);
     panel.add(creditNo);

     panel.add(custID);
     panel.add(customerNo);

     panel.add(apples);
     panel.add(applesNo);

     panel.add(peaches);
     panel.add(peachesNo);

     panel.add(pears);
     panel.add(pearsNo);

     panel.add(total);
     panel.add(itotal);

     panel.add(cost);
     panel.add(icost);

     panel.add(view);
     panel.add(reset);

   } //End Constructor

  public void actionPerformed(ActionEvent event){
     Object source = event.getSource();
     String unit, i;
     double cost;
     Double price;
     int items;
     Integer itms;
     DataOrder order = new DataOrder();

//If View button pressed
//Get data from server and display it
     if(source == view){
        try{
          order  = send.getOrder();
	  creditNo.setText(order.cardnum);
	  customerNo.setText(order.custID);
          applesNo.setText(order.apples);
          peachesNo.setText(order.peaches);
          pearsNo.setText(order.pears);

	  cost = order.icost;
	  price = new Double(cost);
	  unit = price.toString();
	  icost.setText(unit);

	  items = order.itotal;
	  itms = new Integer(items);
	  i = itms.toString();
	  itotal.setText(i);
	} catch (java.rmi.RemoteException e) {
	  System.out.println("Cannot access data in server");	
	}
     }

//If Reset button pressed
//Clear all fields
     if(source == reset){
	creditNo.setText("");
	customerNo.setText("");
	applesNo.setText("");
	peachesNo.setText("");	
	pearsNo.setText("");
	itotal.setText("");
	icost.setText("");
     }
  }
  
   public static void main(String[] args){
        RMIClient2 frame = new RMIClient2();
	frame.setTitle("Fruit Order");
        WindowListener l = new WindowAdapter() {
                public void windowClosing(WindowEvent e) {
                        System.exit(0);
                }
        };

        frame.addWindowListener(l);
        frame.pack();
        frame.setVisible(true);

    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

    try {
      String name = "//" + args[0] + "/Send";
      send = ((Send) Naming.lookup(name));
    } catch (java.rmi.RemoteException e) {
      System.out.println("Cannot create remote server object");
    } catch (java.net.MalformedURLException e) {
      System.out.println("Cannot look up server object");
    } catch(java.rmi.NotBoundException e) {
      System.out.println("Cannot access data in server");
    }
  }
}
