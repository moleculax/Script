package server;

import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

public class RemoteServer extends UnicastRemoteObject
                 implements Send {

  Integer num = null;
  String orders = null;
  int value = 0, get = 0;

  public RemoteServer() throws RemoteException {
    super();
  }

  public void sendOrder(DataOrder order){
   value += 1;
   num = new Integer(value);
   orders = num.toString(); 
   try{
      FileOutputStream fos = new FileOutputStream(orders);
      ObjectOutputStream oos = new ObjectOutputStream(fos);
      oos.writeObject(order);
   }catch (java.io.FileNotFoundException e){
      System.out.println("File not found");
   }catch (java.io.IOException e){      
      System.out.println("Unable to write to file");
   }
  }

  public DataOrder getOrder(){

    DataOrder order = null;

    if(value == 0){
      System.out.println("No Orders To Process");
    }

    if(value > get){ 
      get += 1;
      num = new Integer(get);
      orders = num.toString();
      try{
        FileInputStream fis = new FileInputStream(orders); 
        ObjectInputStream ois = new ObjectInputStream(fis);
        order = (DataOrder)ois.readObject();
      }catch (java.io.FileNotFoundException e){
        System.out.println("File not found");
      }catch (java.io.IOException e){      
        System.out.println("Unable to read file");
      }catch (java.lang.ClassNotFoundException e){
        System.out.println("Data class unavailable");
      }
    }else{
      System.out.println("No Orders To Process");
    }
   return order;
  }

  public static void main(String[] args){
    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }
    String name = "//kq6py.eng.sun.com/Send";
    try {
      Send remoteServer = new RemoteServer();
      Naming.rebind(name, remoteServer);
      System.out.println("RemoteServer bound");
    } catch (java.rmi.RemoteException e) {
      System.out.println("Cannot create remote server object");
    } catch (java.net.MalformedURLException e) {
      System.out.println("Cannot look up server object");
    }
  }
}
