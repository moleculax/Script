package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Send extends Remote {
  public void sendOrder(DataOrder order) throws RemoteException;
  public DataOrder getOrder() throws RemoteException;
}
