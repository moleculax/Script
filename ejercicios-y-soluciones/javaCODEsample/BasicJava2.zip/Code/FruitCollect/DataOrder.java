import java.io.*;

class DataOrder implements Serializable{

  String apples, peaches, pears, cardnum, custID;
  double icost;
  int itotal;
}

