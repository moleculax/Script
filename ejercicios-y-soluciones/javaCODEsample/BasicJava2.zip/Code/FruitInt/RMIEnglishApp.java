import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;
import java.net.*;

import java.rmi.*;
import java.rmi.server.*;

import java.util.*;
import java.text.*;

import java.applet.Applet;

//Make public
public class RMIEnglishApp extends Applet
		 implements ActionListener{ 

   JLabel col1, col2; 
   JLabel totalItems, totalCost; 
   JLabel cardNum, custID;
   JLabel applechk, pearchk, peachchk;

   JButton purchase, reset;

   JTextField appleqnt, pearqnt, peachqnt; 
   JTextField creditCard, customer;
   JTextArea items, cost;

   static Send send;


//Internationalization variables
   Locale currentLocale;
   ResourceBundle messages;
   static String language, country;
   NumberFormat numFormat;

   public void init(){
    language = new String("en");
    country = new String ("US");
 
    if(System.getSecurityManager() == null) {
      System.setSecurityManager(new RMISecurityManager());
    }

     currentLocale = new Locale(language, country);
     messages = ResourceBundle.getBundle("MessagesBundle", currentLocale);
     Locale test = messages.getLocale();

     try {
//Path to host where remote Send object is running
       String name = "//kq6py.eng.sun.com/Send";
       send = ((Send) Naming.lookup(name));
     } catch (java.rmi.NotBoundException e) {
       System.out.println(messages.getString("nolookup"));
     } catch(java.rmi.RemoteException e){
       System.out.println(messages.getString("nolookup"));
     } catch(java.net.MalformedURLException e) {
       System.out.println(messages.getString("nollokup"));
     }

//Create left and right column labels
     col1 = new JLabel(messages.getString("1col"));
     col2 = new JLabel(messages.getString("2col"));

//Create labels and text field components
     applechk = new JLabel("   " + messages.getString("apples"));
     appleqnt = new JTextField();
     appleqnt.addActionListener(this);

     pearchk = new JLabel("   " + messages.getString("pears"));
     pearqnt = new JTextField();
     pearqnt.addActionListener(this);

     peachchk = new JLabel("   " + messages.getString("peaches"));
     peachqnt = new JTextField();
     peachqnt.addActionListener(this);

     cardNum = new JLabel("   " + messages.getString("card"));
     creditCard = new JTextField();
     pearqnt.setNextFocusableComponent(creditCard);

     customer = new JTextField();
     custID = new JLabel("   " + messages.getString("customer"));

//Create labels and text area components
     totalItems = new JLabel("   " + messages.getString("items"));
     totalCost = new JLabel("   " + messages.getString("cost"));

     items = new JTextArea();
     cost = new JTextArea();

//Create buttons and make action listeners
     purchase = new JButton(messages.getString("purchase"));
     purchase.addActionListener(this);

     reset = new JButton(messages.getString("reset"));
     reset.addActionListener(this);

//Set panel layout to 2-column grid
//on a white background
     setLayout(new GridLayout(0,2));
     setBackground(Color.white);

//Add components to panel columns
//going left to right and top to bottom
     add(col1);
     add(col2);

     add(applechk);
     add(appleqnt);

     add(peachchk);
     add(peachqnt);

     add(pearchk);
     add(pearqnt);

     add(totalItems);
     add(items);

     add(totalCost);
     add(cost);

     add(cardNum);
     add(creditCard);

     add(custID);
     add(customer);

     add(reset);
     add(purchase);

   } //End Constructor

  public void actionPerformed(ActionEvent event){
   Object source = event.getSource();
   Integer applesNo, peachesNo, pearsNo, num;
   Double cost;
   String text, text2;
   DataOrder order = new DataOrder();

//If Purchase button pressed  . . .
   if(source == purchase){
//Get data from text fields
    order.cardnum = creditCard.getText();
    order.custID = customer.getText();
    order.apples = appleqnt.getText();
    order.peaches = peachqnt.getText();
    order.pears = pearqnt.getText();

//Calculate total items
    if(order.apples.length() > 0){
//Catch invalid number error
      try{
        applesNo = Integer.valueOf(order.apples);
        order.itotal += applesNo.intValue();
      }catch(java.lang.NumberFormatException e){
        appleqnt.setText(messages.getString("invalid"));
      }
    } else {
      order.itotal += 0;
    }

    if(order.peaches.length() > 0){
//Catch invalid number error
      try{
        peachesNo = Integer.valueOf(order.peaches);
        order.itotal += peachesNo.intValue();
      }catch(java.lang.NumberFormatException e){
        peachqnt.setText(messages.getString("invalid"));
      }
    } else {
      order.itotal += 0;
    }

    if(order.pears.length() > 0){
//Catch invalid number error
      try{
        pearsNo = Integer.valueOf(order.pears);
        order.itotal += pearsNo.intValue();
      }catch(java.lang.NumberFormatException e){
        pearqnt.setText(messages.getString("invalid"));
      }
    } else {
      order.itotal += 0;
    }

//Create number formatter
     numFormat = NumberFormat.getNumberInstance(currentLocale);

//Display running total
     text = numFormat.format(order.itotal);
     this.items.setText(text);

//Calculate and display running cost
     order.icost = (order.itotal * 1.25);
     text2 = numFormat.format(order.icost);
     this.cost.setText(text2);

     try{
        send.sendOrder(order);
      } catch (java.rmi.RemoteException e) {
	System.out.println(messages.getString("send"));	
      }
   }

//If Reset button pressed 
//Clear all fields
    if(source == reset){
     creditCard.setText("");
     appleqnt.setText("");
     peachqnt.setText("");
     pearqnt.setText("");
     creditCard.setText("");
     customer.setText("");

     order.icost = 0;
     cost = new Double(order.icost);
     text2 = cost.toString();
     this.cost.setText(text2);

     order.itotal = 0;
     num = new Integer(order.itotal);
     text = num.toString();
     this.items.setText(text);
    }
  }
}
