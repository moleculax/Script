package divelog;
/**
 * This class creates the content on the
 * Welcome tabbed pane in the Dive Log
 * application.
  * @version 1.0
*/

import javax.swing.*; //imported for buttons, labels, and images
import java.awt.*; //imported for layout manager


public class Welcome extends JPanel
{ //Opens class Welcome


   // Variables for objects that are created.
   // in the class constructor
   
   // Label that to hold the title and an image.
   private JLabel jl;
   
   // Variable for the text area. 
   private JTextArea ta; 
   
   // Label that to hold the image of a diver and fish.
   private JLabel diver; 
  
 
    // Class constructor that provides instruction on
    // how the Welcome object is built.
       
    public Welcome()
    {  // Opens constructor
    
       // Sets the layout by instantiating a 
       // BorderLayout container in the
       // setLayout method.
       
       setLayout(new BorderLayout());
       
       // Sets the background color for this Welcome
       // panel object.
       
       setBackground(Color.white);
       
       // The dive flag image is created by making an 
       // instance of a JLabel on which an image ojbect
       // is initialized, calling the ImageIcon class
       // constructor.
       jl = new JLabel("Java(TM) Technology Dive Log",
            new ImageIcon("images/diveflag.gif"), JLabel.CENTER);
       
       // Sets the font face and size for title.
       jl.setFont(new Font("Times-Roman", Font.BOLD, 17));
       
       // Initialize a text area object that contains the text. 
       // String concatenation is used to limit line length, 
       // and \n creates new lines for a paragraph space.
  
       ta = new JTextArea("This application uses a" +
       " typical Graphical User Interface (GUI), featuring AWT layout "+
       "managers and Project Swing components, such as buttons, borders," +
       " text areas, menus, and more." +
       "\n\nIn addition, the dive log's functionality uses AWT event handlers" +
       ", methods to manipulate data, Java I/O" +
       " to save user input to files, and " +
       "special classes to include HTML pages with live links.");
   
       
       // Sets the font face and size for the text in the
       // text area. Line wrap is also set for the text 
       // area, and the text area cannot be edited.
       
       ta.setFont(new Font("SansSerif", Font.PLAIN, 14));
       ta.setLineWrap(true);
       ta.setWrapStyleWord(true);
       ta.setEditable(false);
       
       // The following method creates a titled border
       // around the entire text area, using the BorderFactory
       // class.
       ta.setBorder(BorderFactory.createTitledBorder(
                 " Welcome to the Java Technology Dive Log "));
        // Creates an image object on the label object
       diver = new JLabel("", 
           new ImageIcon("images/diver.jpg"), JLabel.CENTER);
       // Each of the objects jl, ta, and diver are
       // added to the layout with the add method.
       // The objects are postioned with the constraints:
       // NORTH, CENTER, and SOUTH. 
       // Note that no objects have been added to East
       // or West.
       
       add(jl, BorderLayout.NORTH);
       add(ta, BorderLayout.CENTER);
       add(diver, BorderLayout.SOUTH);
       
      }// Closes Welcome constructor 

  }// Closes class Welcome
