/* testing... */
package org.netbeans.mymodules.createfile;
      
      
public class NewSourceFile {
      
public NewSourceFile(){}
private int newfield;
      
}
