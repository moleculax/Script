import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FileIOServlet extends HttpServlet {
    public void doPost(HttpServletRequest request,
                        HttpServletResponse response)
                        throws ServletException, IOException
   {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<body bgcolor=FFFFFF>");
        out.println("<h2>Button Clicked</h2>");
        String data = request.getParameter("data");
        if (data != null && data.length() > 0) {
          out.println("<STRONG>Text from form:</STRONG>");
          out.println(data);
        } else {
          out.println("No text entered.");
        }
        try {
//Code to write to file
           String outputFileName=
           System.getProperty("user.home",
           File.separatorChar + "home" +
           File.separatorChar + "monicap") +
           File.separatorChar + "text.txt";
           FileWriter fout = new FileWriter(outputFileName);
           fout.write(data);
           fout.close();
//Code to read from file
           String inputFileName =
              System.getProperty("user.home",
              File.separatorChar + "home" +
              File.separatorChar + "monicap") +
              File.separatorChar + "text.txt";
           FileReader fin = new FileReader(inputFileName);
           char c[] = new char[(char)inputFileName.length()];
           fin.read(c);
           String s = new String(c);
           out.println("<P><STRONG>Text from file:</STRONG>");
           out.println(s);
           fin.close();
        } catch(java.io.IOException e) {
            System.out.println("Cannot access text.txt");
        }
        out.println("<P>Return to <A HREF=../simpleHTML.html>Form</A>");
        out.close();
   }
}
