package divelog;

import java.awt.*;
import javax.swing.*;
import java.io.*;

public class NorthPanel extends JPanel 
 { //opens class

    JTextArea instruct; 
    String str;
    BufferedReader br;
    
    public NorthPanel() 
    { //opens constructor

      setBackground(Color.white);
      instruct = new JTextArea(5,60);
      instruct.setLayout(new FlowLayout(FlowLayout.CENTER));
      instruct.setBorder(BorderFactory.createTitledBorder(" Detailing Dives "));
      instruct.setLineWrap(true);
      instruct.setWrapStyleWord(true);
      instruct.setEditable(false);
      readFileIntoTextArea();
      add(instruct);
    } //closes constructor

   private void readFileIntoTextArea() 
    { // opens method
       try 
       { //opens try
          
       File f = new File("divedetails.txt");
       f.createNewFile();
       br = new BufferedReader (new FileReader(f));
         
           while ((str = br.readLine()) != null) 
           {//opens while
           //Adds text file into the JTextArea
             instruct.append(str);
            } //closes while
            
         } // close try
        
        catch (FileNotFoundException fnfe) 
        {//open catch
        JOptionPane.showMessageDialog( null, "File divedetails.txt not found.", null,
                                               JOptionPane.ERROR_MESSAGE );
          System.out.println(fnfe);
        } //close catch
        catch (IOException ioe) 
        {//open catch
        JOptionPane.showMessageDialog( null, "Problem Reading File.", null, 
                                                  JOptionPane.ERROR_MESSAGE );
        }//close catch
        finally
        { //Open finally
          if (br !=null)
          {      
           try
           {
             br.close();
           }
           catch (Exception ignored)
           {
           }
          }//closes if
        } //close finally

    }//closes method

}//closes class



   
