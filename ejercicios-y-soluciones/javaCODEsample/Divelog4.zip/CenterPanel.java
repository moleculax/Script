package divelog;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;




public class CenterPanel extends JPanel implements ActionListener
   { // Opens class

   private JTextArea comments; 
   private JScrollPane scrollpane;
   private JButton saveAs; 
   private JLabel whiteshark;
   private Box box;

   
   public CenterPanel()
   { // open constructor
    
     setBackground(Color.white);
     comments = new JTextArea("Enter comments, such as " +
          "location, water conditions, sea life you observed," +
             " and problems you may have encountered.", 15, 10);
     comments.setLineWrap(true);
     comments.setWrapStyleWord(true);
     comments.setEditable(true);
     comments.setFont(new Font("Times-Roman", Font.PLAIN, 14));
     
     scrollpane = new JScrollPane(comments);
     scrollpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
     
     saveAs = new JButton("Save Comments");
     saveAs.addActionListener( this );
     whiteshark = new JLabel("", 
                    new ImageIcon("images/gwhite.gif"), 
                                       JLabel.CENTER);

     box = Box.createVerticalBox();
     box.add(scrollpane);
     box.add(Box.createVerticalStrut(10));
     box.add(saveAs);
     box.add(Box.createVerticalStrut(15));
     box.add(whiteshark);
     add(box);
     } // closes constructor
   
     public void actionPerformed( ActionEvent evt )
     { // open method
     
       JFileChooser jfc = new JFileChooser();
       jfc.setSize(400, 300);
       Container parent = saveAs.getParent();
       int choice = jfc.showSaveDialog(parent);
       
       if (choice == JFileChooser.APPROVE_OPTION)
         {
           
          String filename = jfc.getSelectedFile().getAbsolutePath();
          try
          { // opens try
            BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
            bw.write(comments.getText());
            bw.flush();
            bw.close();
           } // closes try
         catch (IOException ioe)
          { // open catch
          }// close catch
       }//close if statement
      } //close method
             
   } // Closes class
