import java.io.*;

public class ReadMyFile
  {
  
    public static void main(String[] args)
      {
       // A String variable to hold the text.
       String str;
       
       // The try statement for the code you
       // want to execute.
       try {
         // BufferedReader class holds larger
         // chunks of data and give you the
         // convenient readLine method.
         // The file itself is assocaited with
         // a reader object, specifically
         // FileReader that is wrapped by the
         // BufferedReader class.
         BufferedReader br =
           new BufferedReader(new FileReader("example.txt"));
          // The while statement loops through, meaning
          // while there are lines to read and the lines
          // are not null, or nonexistant, read a line at
          // a time until there aren't any more lines to
          // read, and assign the lines to str, which is
          // a reference to a String object, then print
          // the String to the console. 
          while ((str = br.readLine()) != null)
            {
              System.out.println(str);
             }
            // Then close the stream to the file.
            br.close();
            }
            // In the event the file can't be read,
            // BufferedReader throws an I/O exception.
            // When the exception is caught, print out
            // the error message, or stack trace,
            // to the console.
            catch (IOException ioe)
             {
              System.out.println(ioe);
             }
         }
  }
            