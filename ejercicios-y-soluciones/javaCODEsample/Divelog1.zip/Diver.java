package divelog;

import java.awt.*;
import javax.swing.*;



public class Diver extends JPanel
{ // Opens class

   
} // Closes class
  
