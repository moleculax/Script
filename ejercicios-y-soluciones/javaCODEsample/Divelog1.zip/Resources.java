package divelog;

import javax.swing.*;
import java.awt.*;


public class Resources extends JPanel
{ // Opens class

   
} // Closes class
       
