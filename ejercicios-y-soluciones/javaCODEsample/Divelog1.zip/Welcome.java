package divelog;
/**
 * This class creates the content on the
 * Welcome tabbed pane in the Dive Log
 * application.
 * @version 1.0
*/

import javax.swing.*; //imported for buttons, labels, and images
import java.awt.*; //imported for layout manager


public class Welcome extends JPanel
{ // Opens class

   
} // Closes class
