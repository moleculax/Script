package divelog;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 


public class DiveLog 
{ //Opens DiveLog class
 
  private JTabbedPane tabbedPane;
  private JFrame dlframe; 
  

      
      public DiveLog()
      { //Opens DiveLog constructor
      
      //Create a frame object to add the application
      //GUI components to.
      
        dlframe = new JFrame("A Java(TM) Technology Dive Log");
        
        // Closes from title bar
        //and from menu
        dlframe.addWindowListener(new WindowAdapter() 
        { // Opens addWindowListener method
          public void windowClosing(WindowEvent e)
          { // Opens windowClosing method
             System.exit(0);
           } // Closes windowClosing method
         }); // Closes addWindowListener method
         
                  
         // Tabbed pane with panels for Jcomponents
         
         tabbedPane = new JTabbedPane(SwingConstants.LEFT);
         tabbedPane.setBackground(Color.blue);
         tabbedPane.setForeground(Color.white);
         
         // Calls a method that adds individual tabs to the
         //tabbedpane object.
         populateTabbedPane();
         
         //Calls the method that builds the menu 
         buildMenu();
         
         dlframe.getContentPane().add(tabbedPane);
         
         dlframe.pack();
         dlframe.setSize(765, 690);
         dlframe.setBackground(Color.white);
         dlframe.setVisible(true);
         } // Ends class constructor
         
         private void populateTabbedPane()
           { // Opens populateTabbedPane method definition
           // Create tabs with titles
           
           
           tabbedPane.addTab("Welcome",
                               null,
                               new Welcome(),
                               "Welcome to the Dive Log");
                        
                               
           tabbedPane.addTab("Diver Data",
                               null,
                               new Diver(),
                               "Click here to enter diver data");
                               
           tabbedPane.addTab("Log Dives",
                               null,
                               new Dives(),
                               "Click here to enter dives");
                               
           tabbedPane.addTab("Statistics",
                               null,
                               new Statistics(),
                               "Click here to calculate dive statistics");
                               
           tabbedPane.addTab("Favorite Web Site",
                               null,
                               new WebSite(),
                               "Click here to see a web site");                
           tabbedPane.addTab("Resources",
                               null,
                               new Resources(),
                               "Click here to see a list of resources");         
                     } //Ends populateTabbedPane method
          
         
         private void buildMenu()
         { // Opens buildMenu method definition
           JMenuBar mb = new JMenuBar();
           JMenu menu = new JMenu("File");
           JMenuItem item = new JMenuItem("Exit");
           
           //Closes the application from the Exit 
           //menu item.
           item.addActionListener(new ActionListener()
           { // Opens addActionListener method
             public void actionPerformed(ActionEvent e)
             { // Opens actionPerformed method
                System.exit(0);
              } // Closes actionPerformed method
              
             }); // Closes addActionListener method
             
             menu.add(item);
             mb.add(menu);
             dlframe.setJMenuBar(mb);
             }// Closes buildMenu method
          

     // main method and entry point for app    
     public static void main(String[] args)
     { // Opens main method
     
      DiveLog dl = new DiveLog();
      
      
      } // Closes main method
    

                     
 } //Ends class DiveLog                   
                              
                               
                
