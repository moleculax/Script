package divelog;

import java.awt.*;
import javax.swing.*;


public class Dives extends JPanel
{ // Opens class

   
} // Closes class
   
