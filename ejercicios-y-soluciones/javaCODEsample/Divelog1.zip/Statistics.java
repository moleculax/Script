package divelog;

import javax.swing.*;
import java.awt.*;


public class Statistics extends JPanel
{ // Opens class

   
} // Closes class
