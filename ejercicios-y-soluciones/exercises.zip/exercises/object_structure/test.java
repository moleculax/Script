public class test {
		
		public static void main(String[] a) {
		
		Customer cliente = new Customer();
		
		cliente.customerID=7;
		cliente.status ='0';
		cliente.totalPurchases =100.00;
		cliente.displayCustomerInfo();
						}
			}
			
					
		
		                                   
  		
                     