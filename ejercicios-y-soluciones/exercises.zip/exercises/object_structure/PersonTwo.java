public class PersonTwo {
			
	public String nombre = "Juana de Arco";
	public String es ="Parte de la Historia de Francia";
	
	public void displayQuote() {
	
	System.out.println("nombre"+nombre+", Es "+es);
	
				}
			}