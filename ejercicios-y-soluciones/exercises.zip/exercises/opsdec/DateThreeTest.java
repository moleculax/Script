
public class DateThreeTest {
   
  public static void main (String args[]) {
 
    DateThree myDateThree = new DateThree();
  
    myDateThree.displayDay();

  } 
}
