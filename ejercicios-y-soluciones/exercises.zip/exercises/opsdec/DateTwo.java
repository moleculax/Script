public class DateTwo {

		public int dias =1;
		
		public void  displayDay() {
		
		if (dias==1)
			{
			System.out.println("El "+dias+"es Lunes");
			}
		
		else if (dias==2)
			{
			System.out.println("El "+dias+"  es Martes");
			}
			
			
		
		else {
			System.out.println("Error en dia solicitado");
			} 
			
			
			}
					}