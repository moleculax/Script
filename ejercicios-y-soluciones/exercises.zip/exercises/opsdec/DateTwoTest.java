
public class DateTwoTest {
   
  public static void main (String args[]) {
 
    DateTwo myDateTwo = new DateTwo();
  
    myDateTwo.displayDay();

  } 
}
