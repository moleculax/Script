public class DateThree {
	 
	int dias=1;
	final int Lunes = 1;
	final int Martes = 2;
	final int Miercoles =3 ;
	final int Jueves = 4;
	final int Viernes = 5;
	final int Sabado = 6;
	final int Domingo = 7;
	
	public void displayDay() {
	
	switch(dias) {
	
		case Lunes:
		System.out.println("DIA LUNES");
		break;
		case Martes:
		System.out.println("DIA MARTES");
		break;
		case Miercoles:
		System.out.println("DIA MIERCOLES");
		break;
		case Jueves:
		System.out.println("DIA JUEVES");
		break;
		case Viernes:
		System.out.println("DIA VIERNES");
		break;
		case Sabado:
		System.out.println("DIA SABADO");
		break;
		case Domingo:
		System.out.println("DIA DOMINGO");
		break;
		default:
		System.out.println("ERROR EN EL DIA SOLICITADO");
		
			}
				}
				
			  }
	