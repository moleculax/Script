public class Customer {

		public int id = 0;
		public char status = '0';
		public int compras;
		
		public void displayCustomerInfo() {
		
		System.out.println("ID  " +id);
		System.out.println("Estatus  "+status);
		System.out.println("Compras  "+compras);
						   }
			}
			
			