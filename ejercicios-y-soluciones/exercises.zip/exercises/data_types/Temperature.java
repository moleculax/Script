public class Temperature {

		float gcentigrados,gfarenheit;
		
		public void calculateCelsius() {
		
		
		gcentigrados = 37;
		gfarenheit = (gcentigrados -32)*5/9;
		
		System.out.println("Grados Centigrados a Farenheit:  "+gfarenheit);
		
						}
				}
				
				