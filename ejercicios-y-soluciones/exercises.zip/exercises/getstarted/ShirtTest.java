public class ShirtTest {

	public static void main (String args[]) {
	Shirt myShirt;
	myShirt = new Shirt();
	
	myShirt.displayShirtInformation();
						}
			}
			