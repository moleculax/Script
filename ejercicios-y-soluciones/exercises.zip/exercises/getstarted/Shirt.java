public class Shirt {


	public int shirtID = 0;
	public String description = "-descripcion requerida-";
	public char colorCode = 'U';
	public double price =0.0;
	public int quantifyInStock =0;
	
	
	public void displayShirtInformation() {
	
	System.out.println("ID Camisa"+ shirtID);
	System.out.println("Descripcion de la camiasa: "+ description);
	System.out.println("Codigo del color"+ colorCode);
	System.out.println("Precio de la Camisa"+ price);
	System.out.println("Cantidad en stock: " + quantifyInStock);
	
						}
						
			}
			
			