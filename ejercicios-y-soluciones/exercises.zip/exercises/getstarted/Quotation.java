public class Quotation {

		String quote = "Hola Mundo desde Java";
		public void display() {
			System.out.println(quote);
					}
		    }
		    
		    