public class DateFour {

	public static  void main(String[]a) {
	
	DateOne fecha = new DateOne();
	
	
	fecha.dias_mes =3;
	fecha.fechas_mes=8;
	fecha.fechas_anos=6;
	
	
	fecha.mostrar();
	
	}
	
	}