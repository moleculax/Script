public class DateFourTest {

public int dias_mes; public int fechas_mes; public int fechas_anos;

public void setColocarfecha(int D,int F,int A) {
		dias_mes = D;
		fechas_mes =F;
		fechas_anos = A;
	
						}
						

public void mostrar() {

		
		System.out.println("DIA: "+dias_mes);
		System.out.println("MES: "+fechas_mes);
		System.out.println("ANO: "+fechas_anos);
		
		
			}

}		