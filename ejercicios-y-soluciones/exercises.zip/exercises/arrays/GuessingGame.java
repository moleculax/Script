public class GuessingGame {

        int run[] = new int[5];

public void setGuessingGame() {

        run[1];
        run[2];
        run[3];
        run[4];
        run[5];
        

	public void main (String args[]) {
	
	
	
	
	
					}
			}