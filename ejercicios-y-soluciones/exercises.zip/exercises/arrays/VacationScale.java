public class VacationScale {

int D[] = new int[7];

public void setVacationScale() {

		D[0]=10;
		D[1]=15;
		D[2]=15;
		D[3]=15;
		D[4]=20;
		D[5]=20;
		D[6]=25;
				}
						
public void displayVacationDays(int V) {

if (V >=  6) {

V =6;

System.out.println("Tus VACACIONES SON DE: "+D[V]);

}		
		

				}


			}



		
		
		

