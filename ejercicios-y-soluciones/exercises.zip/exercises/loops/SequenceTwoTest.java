
class SequenceTwoTest {
   
  public static void main (String args[]) {
 
  SequenceTwo mySequence = new SequenceTwo();
  
  mySequence.displaySequence();

  } 
}
