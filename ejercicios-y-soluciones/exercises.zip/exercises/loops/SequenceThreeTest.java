
class SequenceThreeTest {
   
  public static void main (String args[]) {
 
  SequenceThree mySequence = new SequenceThree();
  
  mySequence.displaySequence();

  } 
}
