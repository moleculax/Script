
class CounterTwoTest {
   
  public static void main (String args[]) {
 
  CounterTwo myCounterTwo = new CounterTwo();
  
  myCounterTwo.displayCount();

  } 
}
