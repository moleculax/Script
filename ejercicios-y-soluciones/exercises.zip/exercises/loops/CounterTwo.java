public class CounterTwo {

		final int MAX_COUNT=10;
		int var_01;
	
public void displayCount() {
	
	for (var_01=0; var_01<=MAX_COUNT; var_01++) {
	
	
						
	System.out.println("Conteo: "+var_01);
	
						}
				}
				
			}
	
	
	
		
		