
class CounterThreeTest {
   
  public static void main (String args[]) {
 
  CounterThree myCounterThree = new CounterThree();
  
  myCounterThree.displayCount();

  } 
}
