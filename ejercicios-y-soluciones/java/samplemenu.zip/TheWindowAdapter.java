import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class TheWindowAdapter extends WindowAdapter {
	TheWindowAdapter()
		{
			super();
		}
		public void windowClosing(WindowEvent e) {
				System.exit(0);
		}
}