public class SampleModel {
	int datum;
	SampleModel(int d)
		{
			datum = d;
			return;
		}
	int getDatum()
		{
			return datum;
		}
	void setDatum(int d)
		{
			datum = d;
			return;
		}
}