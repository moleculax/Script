import java.awt.*;
import java.awt.event.*;
/*
	This is a sample action class. It gets a model through
	its constructor.
*/
public class NewAction implements ActionListener {
	SampleModel theModel;
	SampleView theView;

	NewAction(SampleModel sm, SampleView tv)
		{
			theModel = sm;
			theView = tv;
		}
	public void actionPerformed(ActionEvent ae)
		{
			theView.getJLabel().setText(ae.getActionCommand()+theModel.getDatum());
		}
}
