import javax.swing.JFrame;

public class SampleMenu
	{
		public static void main(String[] args)
			{
				JFrame jf;
				SampleModel sm = new SampleModel(33);
				SampleView sv = new SampleView(sm);
				jf = sv.getJFrame();
				jf.pack();
				jf.setVisible(true);
			}
	}