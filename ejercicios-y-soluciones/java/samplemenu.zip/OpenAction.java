import java.awt.*;
import java.awt.event.*;
/*
	This is a sample action class. It gets a model through
	its constructor.
*/
public class OpenAction implements ActionListener {
	SampleModel theModel;
		SampleView theView;

	OpenAction(SampleModel sm, SampleView tv)
		{
			theModel = sm;
			theView = tv;
		}
	public void actionPerformed(ActionEvent ae)
		{
			theView.getJLabel().setText("OpenAction: "+ae.getActionCommand()+theModel.getDatum());
		}
}
