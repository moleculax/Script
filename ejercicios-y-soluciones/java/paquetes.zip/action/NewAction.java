package action;
import java.awt.*;
import java.awt.event.*;
import model.*;
import view.*;
/*
	This is a sample action class. It gets a model trough
	its constructor.
*/
public class NewAction implements ActionListener {
	SampleModel theModel;
	SampleView theView;

	public NewAction(SampleModel sm, SampleView tv)
		{
			theModel = sm;
			theView = tv;
		}
	public void actionPerformed(ActionEvent ae)
		{
			theView.getJLabel().setText(ae.getActionCommand()+theModel.getDatum());
		}
}
