package view;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import model.*;
import action.*;

public class SampleView {

	/* JFrame-related attributes */
	private WindowAdapter windowAdapter;
	private JFrame theJFrame;
	
	/* Model-related attributes */
	private SampleModel theModel;
	
	/* Menu-related attributes */
	private JMenuBar theJMenuBar;
	private JMenu fileMenu, editMenu;
	private JMenuItem newJMI, openJMI, saveJMI, saveAsJMI, closeJMI, exitJMI;
	private JMenuItem undoJMI, cutJMI, copyJMI, pasteJMI, deleteJMI;
	private ActionListener newAction, openAction, saveAction, saveAsAction, closeAction, exitAction;
	private ActionListener undoAction, cutAction, copyAction, pasteAction, deleteAction;
	/*
		This is the actual View
	*/
	private JLabel jl;
	/*
		Constructor
	*/
	public SampleView(SampleModel sm)
		{
		
			/*
				Set up the model
			*/
			theModel = sm;
			
			/* Set up the window */
			theJFrame = new JFrame("Working with menus");
			windowAdapter = new TheWindowAdapter();
			theJFrame.addWindowListener(windowAdapter);
			
			/*
				Set up the contents
			*/
			JPanel jp = new JPanel();
			jl = new JLabel("Hi - this is a menu test!");
			jp.setBorder(BorderFactory.createEmptyBorder(
																					30, //top
																					100, //left
																					10, //bottom
																					100) //right
																					);
			jp.add(jl);
			theJFrame.getContentPane().add(jp, BorderLayout.CENTER);
			
			/* We are ready to show the model contents */
			
			/* Set up the menus and menu bar */

			fileMenu = new JMenu("File");
			/* We create the File options */
			newJMI = new JMenuItem("New...");
			openJMI = new JMenuItem("Open...");
			saveJMI = new JMenuItem("Save");
			saveAsJMI = new JMenuItem("Save as...");
			closeJMI = new JMenuItem("Close");
			exitJMI = new JMenuItem("Quit");
			/* These we add to the File menu*/
			fileMenu.add(newJMI);
			fileMenu.add(openJMI);
			fileMenu.add(saveJMI);
			fileMenu.add(saveAsJMI);
			fileMenu.add(closeJMI);
			fileMenu.add(exitJMI);
			/* Now we create the Action classes */
			newAction = new NewAction(theModel,this);
			openAction = new OpenAction(theModel,this);
			saveAction = new SaveAction(theModel,this);
			saveAsAction = new SaveAsAction(theModel,this);
			closeAction = new CloseAction(theModel,this);
			exitAction = new ExitAction(theModel,this);
			/* Now we tell each option where it action method is */
			newJMI.addActionListener(newAction);
			openJMI.addActionListener(openAction);
			saveJMI.addActionListener(saveAction);
			saveAsJMI.addActionListener(saveAsAction);
			closeJMI.addActionListener(closeAction);
			exitJMI.addActionListener(exitAction);
			
			/* Now we do the same with the Edit menu */
			editMenu = new JMenu("Edit");
			/* We create the actions */
			undoAction = new UndoAction(theModel,this);
			cutAction = new CutAction(theModel,this);
			copyAction = new CopyAction(theModel,this);
			pasteAction = new PasteAction(theModel,this);
			deleteAction = new DeleteAction(theModel,this);
			/* We create the options*/
			undoJMI = new JMenuItem("Undo");
			cutJMI = new JMenuItem("Cut");
			copyJMI = new JMenuItem("Copy");
			pasteJMI = new JMenuItem("Paste");
			deleteJMI = new JMenuItem("Delete");
			/*Now we tell each option where its action method is*/
			undoJMI.addActionListener(undoAction);
			cutJMI.addActionListener(cutAction);
			copyJMI.addActionListener(copyAction);
			pasteJMI.addActionListener(pasteAction);
			deleteJMI.addActionListener(deleteAction);
			/* Add the JMenuItems to the Edit menu*/
			editMenu.add(undoJMI);
			editMenu.add(cutJMI);
			editMenu.add(cutJMI);
			editMenu.add(pasteJMI);
			editMenu.add(deleteJMI);
			/* Finally we create a menu bar*/
			theJMenuBar = new JMenuBar();
			/* Then we add the menus to the menu bar */
			theJMenuBar.add(fileMenu);
			theJMenuBar.add(editMenu);
			theJFrame.setJMenuBar(theJMenuBar);
		}
	
	public JFrame getJFrame()
		{
			return theJFrame;
		}
	public JLabel getJLabel()
		{
			return jl;
		}
}