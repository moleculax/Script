import javax.swing.JFrame;
import model.*;
import action.*;
import view.*;

public class SampleMenu
	{
		public static void main(String[] args)
			{
				JFrame jf;
				SampleModel sm = new SampleModel(33);
				SampleView sv = new SampleView(sm);
				jf = sv.getJFrame();
				jf.pack();
				jf.setVisible(true);
			}
	}