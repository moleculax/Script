package model;
public class SampleModel {
	private int datum;
	public SampleModel(int d)
		{
			datum = d;
			return;
		}
	public int getDatum()
		{
			return datum;
		}
	public void setDatum(int d)
		{
			datum = d;
			return;
		}
}